import React from 'react'
import { FaChevronDown} from "react-icons/fa";


const Work = () => {
  return (
    <>
    <section>
        <div className='container'>
            <div className='row btnc'>
            <button className='btn-main2'>How it Works <FaChevronDown /></button>
            </div>
        </div>
    </section>
    </>
  )
}

export default Work