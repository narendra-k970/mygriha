import React from 'react'

const ShopOnline = () => {
  return (
    <div>ShopOnline</div>
  )
}

export default ShopOnline