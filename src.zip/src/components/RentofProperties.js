import React from 'react'

const RentofProperties = () => {
  return (
    <div>RentofProperties</div>
  )
}

export default RentofProperties