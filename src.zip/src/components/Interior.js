import React from 'react'
import Dashboard from '../componentc/Dashboard'

const Interior = () => {
  return (
    <>
    <Dashboard />
    </>
  )
}

export default Interior