import React from 'react'


const Architecture = () => {
  
  return (
    <>

    </>
  )
}

export default Architecture