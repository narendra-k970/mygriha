import React from 'react'

const BidProject = () => {
  return (
    <div>BidProject</div>
  )
}

export default BidProject