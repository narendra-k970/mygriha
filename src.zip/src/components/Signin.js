import React from 'react'
import Signup from '../componentc/Signup'


const Signin = () => {
  return (
        <>
        <Signup/>
        </>
    )
}

export default Signin