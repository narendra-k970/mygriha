import React from 'react'


const Wishlist = () => {
  return (
    <>
    <div className="tab-content mt-2">
    <div className='row'>
    <div class="table-container">
    <table>
      <thead>
        <tr>
          <th>Building Name</th>
          <th>Building Type</th>
          <th>Plot Length*Width	</th>
          <th>No of Floor</th>
          <th>Location</th>
          <th>No of Bedrooms</th>
          <th>No of toilets</th>
          <th>Vastu</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
       
      </tbody>
    </table>
  </div>
    </div>
    </div>
    </>
  )
}

export default Wishlist