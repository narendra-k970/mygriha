import React from 'react'
import Book from "../componenth/Book"

const Service = () => {
  return (
    <>
    <div>
        <Book 
        image="../img/bedroom.webp"
        title="Construction"
        description="Start at Rs-1000/"
        />
    </div>
    </>
  )
}

export default Service