import React from 'react'

const Architecture = () => {
  return (
    <div>Architecture</div>
  )
}

export default Architecture