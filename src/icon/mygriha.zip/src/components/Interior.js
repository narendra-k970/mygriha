import React from 'react'

const Interior = () => {
  return (
    <>
    
    </>
  )
}

export default Interior